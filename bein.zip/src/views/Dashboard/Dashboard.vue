<template>
	<div class="home">
		<h1 class="page__title"><i :class="$route.meta.icon" class="page__title_icon"></i> {{$route.name}}</h1>
		<div class="home__content">
			<div class="xrp_block card card--gradient row-flex align-items-center justify-content-between">
				<div class="balance">
					<div class="balance__icon">
						<i class="icon-currancy"></i>
						<svg class="balance__circle" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
							<circle class="circle__main" cx="50" cy="50" r="47" stroke="#fff" stroke-width="5" stroke-dasharray="300" :stroke-dashoffset="investmentXRPOffset - 290" />
							<circle class="circle__investment" cx="50" cy="50" r="47" stroke="rgba(255,255,255,.5)" stroke-width="5" stroke-dasharray="300" :stroke-dashoffset="investmentXRPOffset" />
						</svg>
					</div>
					<div class="balance__info">
						<div class="balance__title">Your XRP balance</div>
						<div class="balance__actual">
							<div class="atual__item">
								<small class="balance__currancy"><i class="icon-currancy"></i></small>
								{{balanceXRPArray[0]}}<small>.{{balanceXRPArray[1] || '00'}}</small>
							</div>
						</div>
						<div class="add_wallet">
							<beButton
								title="Add wallet"
								:link="true"
								@click="goToWalets"
							>
								<i class="icon-plus-outline" slot="icon-left"></i>
							</beButton>
						</div>
					</div>
				</div>
				<div class="btns">
					<beButton 
						type="button" 
						title="Send" 
						:outline="true" 
						:white="true"
						@click="openSendModal"
					><i class="icon-sign-out" slot="icon-left"></i></beButton>
					<beButton 
						type="button" 
						title="Receive" 
						:outline="false" 
						:white="true"
						class="ml10"
						@click="openOutputModal"
					><i class="icon-sign-in" slot="icon-left"></i></beButton>
				</div>
			</div>
			<div class="card usdx_block card--gradient-purple row-flex align-items-center justify-content-between">
				<div class="balance">
					<div class="balance__icon">
						<!-- <i class="icon-wallet-outline"></i> -->
						<img class="currency__icon" src="../../assets/balance.svg" alt="">
						<svg class="balance__circle" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
							<circle class="circle__main" cx="50" cy="50" r="47" stroke="#fff" stroke-width="5" stroke-dasharray="300" :stroke-dashoffset="investmentUSDXOffset - 290" />
							<circle class="circle__investment" cx="50" cy="50" r="47" stroke="rgba(255,255,255,.5)" stroke-width="5" stroke-dasharray="300" :stroke-dashoffset="investmentUSDXOffset" />
						</svg>
					</div>
					<div class="balance__info">
						<div class="balance__title">Your USDX balance</div>
						<div class="balance__actual">
							<div class="atual__item">
								{{balanceUSDXArray[0]}}<small>.{{balanceUSDXArray[1] || '00'}}</small> <small>USDX</small>
							</div>
						</div>
						<div class="add_wallet">1 USDX = 1$</div>
					</div>
				</div>
				<div class="btns">
					<beButton 
						type="button" 
						title="Send" 
						:outline="true" 
						:white="true"
					><i class="icon-sign-out" slot="icon-left"></i></beButton>
					<beButton 
						type="button" 
						title="Receive" 
						:outline="false" 
						:white="true"
						class="ml10"
					><i class="icon-sign-in" slot="icon-left"></i></beButton>
				</div>
			</div>
			<div class="hold_block card card--white">
				<div class="balance">
					<div class="balance__info">
						<div class="balance__title">
							HODL balance
							<bePrompt text="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Odit a, doloribus tenetur ipsum eveniet incidunt rem totam labore eos ut."></bePrompt>
						</div>
						<div class="balance__actual row-flex">
							<div class="atual__item">
								<div>
									<small class="balance__currancy"><i class="icon-currancy"></i></small>
									{{investmentXRPArray[0]}}<small>.{{investmentXRPArray[1] || '00'}}</small>
								</div>
								<div class="profit">
									<span class="profit__finance">
										<i class="icon-arrow-up-double"></i> 
										{{profitXRPArray[0]}}<small>.{{profitXRPArray[1] || '00'}} XRP</small>
									</span> for yesterday
								</div>
							</div>
							<div class="atual__item">
								<div>
									{{investmentUSDXArray[0]}}<small>.{{investmentUSDXArray[1] || '00'}} USDX</small>
								</div>
								<div class="profit">
									<span class="profit__finance loss">
										<i class="icon-arrow-up-double"></i> 
										{{profitUSDXArray[0]}}<small>.{{profitUSDXArray[1] || '00'}} USDX</small>
									</span> for yesterday
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="graph_block">
				<div class="graph">
					<img src="../../assets/graph.png" alt="">
				</div>
			</div>
			<div class="transactions transactions_block">
				<div class="transactions__header row-flex align-items-center justify-content-start">
					<div class="block__title">Transaction history</div>
					<beSelect
						:selectArray="sortingList"
						v-model="selectedSortItem"
						:sortingIcon="true"
						:transparent="true"
					></beSelect>
					<div class="block__link">
						<router-link :to="{name: 'Wallets'}" class="btn btn-link more_link"><span>Details</span> <i class="icon-arrow-right"></i></router-link>
					</div>
				</div>
				<div class="transactions__body" v-if="history">
					<vueCustomScrollbar
						:settings="{
							wheelPropagation: false
						}"
						class="transactions__wrapper"
					>
						<div 
							class="card card--white history" 
							v-for="(item, idx) in history" 
							:key="idx" 
							:class="[item.status == 'Rejected' ? 'alert' : item.status == 'Approved' ? 'success' : 'inprogress']"
						>
							<div class="history__date">{{item.date}}</div>
							<div class="history__planish_link">
								<button class="wallet_btn">
									<span v-if="item.buttonText === 'Wallet replenishment'"><i class="icon-sign-in" slot="icon-left"></i></span>
									<span v-else><i class="icon-sign-out" slot="icon-left"></i></span>
									<span class="wallet_btn__text">
										<span class="wallet_btn__title">{{item.buttonText}}</span>
										<span class="wallet__name">Wallet: {{item.waletName}}</span>
									</span>
								</button>
							</div>
							<div class="history__status">{{item.status}}</div>
							<div class="history__finance">{{item.summ}} <small>{{item.currency == 1 ? 'USDX' : 'XRP'}}</small></div>
						</div>
					</vueCustomScrollbar>
				</div>
				<div class="transactions__body empty" v-else>
					<div class="card card--white text-center">
						<p class="icon"><i class="icon-smile-sad"></i></p>
						<p class="empty__text">You have no transactions</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import vueCustomScrollbar from 'vue-custom-scrollbar';
import "vue-custom-scrollbar/dist/vueScrollbar.css";
import {formatCurency} from '@/helpers/helpers'
export default {
  components: { vueCustomScrollbar },
	name: "Dashboard",
	data: ()=>({
		XRP: {
			balance: 12021.23,
			investment: 2256.15,
			profit: 532.23,
		},
		USDX: {
			balance: 9854,
			investment: 3258.15,
			profit: 152.23,
		},
		// history: null,
		history: [
			{
				id: 1,
				date: '20/20/2020',
				status: 'Rejected',
				summ: '+320',
				buttonText: 'Wallet replenishment',
				currency: 1,
				waletName: 'Walet Name'
			},
			{
				id: 2,
				date: '20/20/2020',
				status: 'Approved',
				summ: '+320',
				buttonText: 'Wallet replenishment',
				currency: 2,
				waletName: 'Walet Name'
			},
			{
				id: 3,
				date: '20/20/2020',
				status: 'Waiting',
				summ: '+320',
				buttonText: 'Funds output',
				currency: 1,
				waletName: 'Walet Name'
			},
			{
				id: 4,
				date: '20/20/2020',
				status: 'Approved',
				summ: '+320',
				buttonText: 'Funds output',
				currency: 2,
				waletName: 'Walet Name'
			},
			{
				id: 5,
				date: '20/20/2020',
				status: 'Waiting',
				summ: '+320',
				buttonText: 'Funds output',
				currency: 1,
				waletName: 'Walet Name'
			},
			{
				id: 6,
				date: '20/20/2020',
				status: 'Approved',
				summ: '+320',
				buttonText: 'Funds output',
				currency: 1,
				waletName: 'Walet Name'
			},
		],
		sortingList:[
            {value: 1, label: 'По дате транзакции'},
            {value: 2, label: 'По сумме'},
            {value: 3, label: 'По кошельку'},
            {value: 4, label: 'По статусу'},
		],
		selectedSortItem: null
	}),
	computed:{
		investmentXRPOffset(){
			return 300 * this.XRP.investment / this.XRP.balance + 290;
		},
		investmentUSDXOffset(){
			return 300 * this.USDX.investment / this.USDX.balance + 290;
		},
		balanceXRPArray(){
			return formatCurency(this.XRP.balance).split('.');
		},
		investmentXRPArray(){
			return formatCurency(this.XRP.investment).split('.');
		},
		profitXRPArray(){
			return formatCurency(this.XRP.profit).split('.');
		},
		balanceUSDXArray(){
			return formatCurency(this.USDX.balance).split('.');
		},
		investmentUSDXArray(){
			return formatCurency(this.USDX.investment).split('.');
		},
		profitUSDXArray(){
			return formatCurency(this.USDX.profit).split('.');
		}
	},
	methods: {
		openSendModal(){
			this.$modal.show('modal')
		},
		openOutputModal(){
			this.$modal.show('modal-output')
		},
		goToWalets(){
			this.$router.push({name: 'Wallets'})
		}
	}
};
</script>
<style lang="scss" src="./Dashboard.scss"></style>
