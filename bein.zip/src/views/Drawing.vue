<template>
    <h1>{{$route.name}}</h1>
</template>