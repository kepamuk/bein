<template>
	<div class="about">
		<h1>{{$route.name}}</h1>
	</div>
</template>
